'''
ToDo Script 2.0
Dev: WR Browning
This script reads in data from a text file and then prompts 
the user to select one of the 5 options shown below:

1) Show current data
2) Add a new item.
3) Remove an existing item.
4) Save Data to File
5) Exit Program

Updates: Key operations have been functionalized and added to a class
of operations for working with lists.
'''

class DoStuffWithTheList(object):
    #functions/methods
    #----------------------------------Open The File Containing The List----------------------------------
    @staticmethod  # We will talk about this in Module 7
    def opnList(filepath, filename):
        #  initialize lists for task ID (cnt), task (task), task priority (pri)
        lstCnt = []
        lstTask = []
        lstPri = []
        with open(filepath + "\\" + filename, 'r') as f:
            # for each line in 'f' do the indented stuff
            for line in f:
                # split each line on "," & make it into a list
                list = line.split(",")
                # make the length of the list into an index
                n = len(list) - 1
                # find the carriage return if it exists and delete
                list[n] = list[n].replace('\n', '')
                # add list object to other lists
                lstTask.append(list[0])
                lstPri.append(list[1])
                '''
                each time the for loop cycles lstCnt will be appended
                with a new length value. This is a cheap way to make
                sequential ID's
                '''
                lstCnt.append(len(lstTask))
                # print the list of the original file
                # test print(lstTask[len(lstTask)-1],lstPri[len(lstPri)-1])
        # close the file, we have the initial data no need to keep it open
        f.close()
        dictFirst = {"cnt": lstCnt, "task": lstTask, "priority": lstPri}
        return dictFirst

    #----------------------------------Print the Current List----------------------------------
    @staticmethod
    def prntList(dictCur):
        for i in dictCur['cnt']:
            n = i - 1
            # this will print each the value at n for each key in the dictionary
            print(dictCur['cnt'][n], dictCur['task'][n], dictCur['priority'][n])
        print("")
    #----------------------------------Append the Current List----------------------------------
    @staticmethod
    def appList(dictCur):
        #extract the lists from the dictionary
        lstTask=dictCur['task']
        lstPri=dictCur['priority']
        lstCnt = dictCur['cnt']
        # initialize in1
        in1 = None
        # while is not 'x' for exit evaluation in1
        while in1 != "x":
            in1 = input("add task or 'x' to return to the menu\n")
            # this exits out of this option and returns back to
            # the main menu
            if in1 == "x":
                break
            # append each list (in each key) with a new list object
            else:
                # assign a priority for the new entry
                in2 = input("priority\n")
                # append the list with the new entries
                lstTask.append(in1)
                lstPri.append(in2)
                # the new length of the task list
                # defines the ID
                cnt = len(lstTask)
                lstCnt.append(cnt)
        # reassign the lists to the dictionary
        dictNew = {"cnt": lstCnt, "task": lstTask, "priority": lstPri}
        print ("the dictionary has been appended")
        return dictNew

    #----------------------------------Remove An Item From The Current List----------------------------------
    @staticmethod
    def remList(dictCur):
        # extract the lists from the dictionary
        lstTask = dictCur['task']
        lstPri = dictCur['priority']
        # show the current task list first so that the
        # user can decide with ID number (row number)
        # to delete
        DoStuffWithTheList.prntList(dictCur)
        # Enter the ID of the row to be removed.
        in3 = int(input("Select the ID of the task you want to remove"))
        # for loop that delete the items at row in3
        # in the list value for each key
        for key in dictCur.keys():
            del dictCur[key][in3 - 1]
            # The ID numbers could be off so reassign ID's
            # for lstCnt with a simple for loop
            num = 0
            lstCnt = []
            for v in dictCur["cnt"]:
                num = num + 1
                lstCnt.append(num)
            # update only the dictionary key 'cnt'
                dictCur['cnt'] = lstCnt
        dictNew = {"cnt": lstCnt, "task": lstTask, "priority": lstPri}
        print ("the dictionary has been reduced")
        return dictNew
    #----------------------------------Save The Current List To A File----------------------------------
    @staticmethod
    def sveList(filepath,filename,dictCur):
        # Open a file named for FNd as writable (this will overwrite the existing file)
        objFile = open(filepath + "\\" + filename, "w")  # "a" for appending, "r" for reading, "w" for writing
        # iteratively define each value item as a string and write it to the new file
        for i in dictCur['cnt']:
            n = i - 1
            line_new = str(dictCur['task'][n]) + "," + str(dictCur['priority'][n])
            print(line_new)
            # objFile.write(str(tplList[row]) + "\n")
            objFile.write(line_new + "\n")
        # close the file and break the while loop
        # close the file
        objFile.close()
        print("The To Do list has been saved to: " + str(filepath) + "\\"+ str(filename))

#----------------------------------Main Program----------------------------------
#Set the filename and path
FPd = "C:\\_PythonClass"
FNd = "Todo.txt"

#Open file, grab the initial data, populate the lists, close the file
dictTodo = DoStuffWithTheList.opnList(FPd,FNd)

#Initialize the selection input
inSel=None
#While the selection is not 5, evaluate other selections
while inSel!=5:
    #A menu of 5 selections
    inSel=input("What would you like \"to do\"?\n"
                "(Make a selection from the menu below)\n"
                "(1) View the current task list\n"
                "(2) Add a task\n"
                "(3) Remove a task\n"
                "(4) Save current task list\n"
                "(5) Exit Program\n"
                "Selection: \n")
    #5) Exit Program
    if inSel=="5":
        exit()
    #1) Show current data
    elif inSel=="1":
        #print(dictTodo)
        DoStuffWithTheList.prntList(dictTodo)
    #2) Add a new item
    elif inSel=="2":
        dictTodo=DoStuffWithTheList.appList(dictTodo)
    #3) Remove an existing item.
    elif inSel=="3":
        dictTodo=DoStuffWithTheList.remList(dictTodo)
        DoStuffWithTheList.prntList(dictTodo)
    #4) Save Data to File
    elif inSel =="4":
        DoStuffWithTheList.sveList(FPd,FNd,dictTodo)