'''
Hangman Game
Dev: WR Browning*
*This is a modified version of a script detailed in 
Dawson, M, "Python Programming, for the absolute beginner", 
Course Technology: 2010, pages 148-154.

The classic game of hangman. The challenger enters a word 
and the player has to guess it one letter at a time.  If 
the player exceed the maximum number of guesses then the 
stick figure gets hanged.

Flow of the game:
1) The Player(s) decide(s) to play the computer or a Challenger.
2) The Challenger enters a word or the "computer" selects one from
an internal list. 
3) The Player guesses each letter in that word and is informed if
each guess is in the word or not until either the maximum
number of guesses is reached or the word is completed.
'''
# ------------------Imports------------------
#imports
import random

#The Hangman graphics have been pickled in a file
#the pickle feature needs to be imported so that
#the pickled hangman can be accessed.
import pickle

#------------------Define Functions------------------
class UserInput(object):
    '''
    This function evaluates whether a user input is the 
    integer"1" or "2".
    '''
    @staticmethod  # We will talk about this in Module 7
    def OneTwo(UInt):
        while UInt != 1 and UInt != 2:
            try:
                UInt = int(input('Enter \'1\' or \'2\': '))
            except ValueError as e:
                print("That was not an integer!")
        return UInt

    '''
    This function evaluates two things about a user input:
        1) Does it contain only letters.
        2) Does it contain more than the maximum number 
           of characters.
    '''
    @staticmethod
    def isAlpha(strIn,lenMax,errMsg):
        while True:
            if strIn.isalpha()== False or len(strIn)>lenMax:
                strIn = input(str(errMsg) + " \n")
            else: break
        return strIn

#------------------Main Program------------------

#This while true statement is neccessary for allowing
#the user to run the program again for another game.
#The prompt for this is at the end of the script.
while True:
    #------------------Creating Constants------------------
    '''
    Get the "hangmen" graphics from the HNGMN.dat file
    and store them in two different tuples: one for 7 guesses
    and one for 13 guesses. The user will have the option to
    select the number of guesses as a level choice later.
    '''
    with open('C:\\_PythonClass\\HNGMN.dat', 'rb') as f:
        data = pickle.load(f)
    HANGMAN7 = (data[0],data[1],data[3],data[5],data[7],data[9],data[11],data[13])
    HANGMAN13 = data

    #------------------Welcome Screen & Menu ------------------

    print('\nWelcome to Hangman. Good Luck')
    plyr=None
    print("Are you playing the challenger or the computer? \n"
          "(1) Challenger\n"
          "(2) Computer\n")
    plyr = UserInput.OneTwo(plyr)

    #------------------Word List------------------

    '''
    If there is a challenger then this will prompt
    for a word to be input.
    Otherwise the list of words will default to a fixed 
    list or words.
    '''

    if plyr == 1:
        lstWords=None
        reqWord = str("Challenger: \n"
                      "Enter a word that is 6 characters or less"
                       " and contains no numbers: \n")
        wordIn = input(reqWord)

        #check that the challengers word meets the word
        #requirements (reqWord).
        wordIn = UserInput.isAlpha(wordIn,6,reqWord)
        #make input lower case
        wordIn = wordIn.lower()

        #set lstWords to wordIn
        lstWords = [wordIn]

        #print 800 carriage returns so that
        #the player does not see the word input
        #by the challenger
        print('\n' * 800)  # prints 800 line breaks
    if plyr == 2:
        lstWords=['boat','ball','snow','mom','dad']

    #------------------Initializing the Variables------------------

    word = str(random.choice(lstWords)) #select a random word to be guessed
    lstSoFar=[]#list of correct letters so far
    wordSoFar=""# string assembled from lstSoFar
    for l in word:
        lstSoFar.append(" _ ")

    intWrng = 0 #initialize the number of wrong guesses (integer)
    lstUsed = [] #initialize list for letters used

    #------------------Set Max. Guesses------------------
    '''
    A level selection will determine if the Player
    has 7 (hard) or 13 guesses (easy)
    '''
    lvl = None
    print("There are two levels of difficulty:\n",
    "(1) Easy (13 guesses) \n",
    "(2) Hard (7 guesses) \n",)

    #Check to make sure the input was either 1 or 2
    lvl = UserInput.OneTwo(lvl)

    if lvl == 1:
        HANGMAN = HANGMAN7
    elif lvl == 2:
        HANGMAN = HANGMAN13
    MAX_WRONG = len(HANGMAN)-1

    #------------------Creating the Main Loop------------------
    '''while the number of wrong guesses is less than the maximum and
       the wordSoFar does not equal the word'''

    while intWrng < MAX_WRONG and wordSoFar != word:
        print(HANGMAN[intWrng])#print the place in the HANGMAN list
        #using the current iteration integer "wrong"

        '''
        print the current status of letters used and correct letters
        '''

        print("\nYou've used the following letters:\n", lstUsed)
        #for i in lstSofar:
        #    strSoFar=
        print("\nSo far, the word is: \n", ' '.join(lstSoFar),"\n")


        #Ask the user to guess a letter
        guess=input("\n\nEnter your letter guess \n")
        errMsg = str("\n\nPlease make sure that you are entering \n"
                     "one single letter at a time. \n"
                     "Try again. \n")
        #Make sure the guess is a letter and only one letter
        guess = UserInput.isAlpha(guess,1,errMsg)

        guess=guess.lower()#turn the guess into all upper case letters

        #Determines if a letter has already been used
        while guess in lstUsed:
            print("You have already guessed the letter "+ guess)
            guess=input("guess a letter: ")
            guess = guess.lower()
        lstUsed.append(guess)

        #Evaluates if the guess is in the word
        if guess in word:
            print("\nYes!", guess, "is in the word!")
            #Create a temp list to include the guess
            new=[]
            for i in range(len(word)):
                if guess == word[i]:
                    new.append(guess)
                else:
                    new.append(lstSoFar[i])
            #Set temp list to lstSoFar
            lstSoFar = new
            wordSoFar = ""  # string assembled from lstSoFar
            for letter in range(len(lstSoFar)):
                wordSoFar +=lstSoFar[letter]

        else:
            print("\nSorry,", guess, "is not in the word")
            intWrng+=1

    #If the while loop is broken then it is
    #either due to exceeding the max number
    #of guesses or getting all of the letters
    #correct.
    if intWrng ==MAX_WRONG:
        print(HANGMAN[intWrng])
        print("\nYou've been hanged! :( ")
    else:
        print("\nYou guessed it!")
    print ("\nThe word was", word,"\n")

    #------------------Restart Program Option------------------
    #This allows the user to run again or quit
    while True:
        answer = input('Run again? (y/n): ')
        if answer in ('y', 'n'):
            break
        print ('Invalid input')
    if answer == 'y':
        continue
    else:
        print ('Goodbye')
        break
