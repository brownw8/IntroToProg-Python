'''
ToDo Script
Dev: WR Browning
This script reads in data from a text file and then prompts 
the user to select one of the 5 options shown below:

1) Show current data
2) Add a new item.
3) Remove an existing item.
4) Save Data to File
5) Exit Program
'''

#set the filename and path
FPd = "C:\\_PythonClass"
FNd = "Todo.txt"

#initialize lists for task ID (cnt), task (task), task priority (pri)
lstCnt=[]
lstTask=[]
lstPri=[]

#open file, grab the initial data, populate the lists, close the file
with open(FPd + "\\" + FNd, 'r') as f:
    #for each line in 'f' do the indented stuff
    for line in f:
        #split each line on "," & make it into a list
        list=line.split(",")
        #make the length of the list into an index
        n=len(list)-1
        #find the carriage return if it exists and delete
        list[n]=list[n].replace('\n','')
        #add list object to other lists
        lstTask.append(list[0])
        lstPri.append(list[1])
        '''
        each time the for loop cycles lstCnt will be appended
        with a new length value. This is a cheap way to make
        sequential ID's
        '''
        lstCnt.append(len(lstTask))
        #print the list of the original file
        #test print(lstTask[len(lstTask)-1],lstPri[len(lstPri)-1])
#close the file, we have the initial data no need to keep it open
f.close()

#add the 3 lists as values in a dictionary
dictTodo = {"cnt": lstCnt, "task": lstTask, "priority": lstPri}
        #print(type(line),line,list)

#initialize the selection input
inSel=None
#While the selection is not 5, evaluate other selections
while inSel!=5:
    #A menu of 5 selections
    inSel=input("What would you like to do?\n"
                "(Make a selection from the menu below)\n"
                "(1) View the current task list\n"
                "(2) Add a task\n"
                "(3) Remove a task\n"
                "(4) Save current task list\n"
                "(5) Exit Program\n"
                "Selection: \n")
    #5) Exit Program
    if inSel=="5":
        exit()
    #1) Show current data
    elif inSel=="1":
        # print(dictTodo)
        for i in dictTodo['cnt']:
            n = i - 1
            #this will print each the value at n for each key in the dictionary
            print(dictTodo['cnt'][n], dictTodo['task'][n], dictTodo['priority'][n])
        print("")
    #2) Add a new item
    elif inSel=="2":
        #initialize in1
        in1 = None
        #while is not 'x' for exit evaluation in1
        while in1 !="x":
            in1=input("add task or 'x' to return to the menu\n")
            #this exits out of this option and returns back to
            #the main menu
            if in1 =="x":
                break
            #append each list (in each key) with a new list object
            else:
                #assign a priority for the new entry
                in2=input("priority\n")
                #append the list with the new entries
                lstTask.append(in1)
                lstPri.append(in2)
                #the new length of the task list
                #defines the ID
                cnt=len(lstTask)
                lstCnt.append(cnt)
        #reassign the lists to the dictionary
        dictTodo={"cnt":lstCnt,"task":lstTask,"priority":lstPri}
    #3) Remove an existing item.
    elif inSel=="3":
        #show the current task list first so that the
        #user can decide with ID number (row number)
        #to delete
        for i in dictTodo['cnt']:
            n = i - 1
            print(dictTodo['cnt'][n], dictTodo['task'][n], dictTodo['priority'][n])
        print("")
        #Enter the ID of the row to be removed.
        in3 = int(input("Select the ID of the task you want to remove"))
        #for loop that delete the items at row in3
        #in the list value for each key
        for key in dictTodo.keys():
            del dictTodo[key][in3-1]
            #The ID numbers could be off so reassign ID's
            #for lstCnt with a simple for loop
            num=0
            lstCnt = []
            for v in dictTodo["cnt"]:
                num=num+1
                lstCnt.append(num)
            #update only the dictionary key 'cnt'
            dictTodo['cnt']=lstCnt
        for i in dictTodo['cnt']:
            n = i - 1
            print(dictTodo['cnt'][n], dictTodo['task'][n], dictTodo['priority'][n])
        print("")
    #4) Save Data to File
    elif inSel =="4":
        #Open a file named for FNd as writable (this will overwrite the existing file)
        objFile = open(FPd + "\\" + FNd, "w")  # "a" for appending, "r" for reading, "w" for writing
        #iteratively define each value item as a string and write it to the new file
        for i in dictTodo['cnt']:
            n = i - 1
            line_new = str(dictTodo['task'][n])+","+ str(dictTodo['priority'][n])
            print(line_new)
            # objFile.write(str(tplList[row]) + "\n")
            objFile.write(line_new + "\n")
        # close the file and break the while loop
        #close the file
        objFile.close()

